export default function ProductDetailStorage({ storage }) {
  return (
    <p>
      <strong>Storage instructions:</strong> {storage}
    </p>
  );
}
